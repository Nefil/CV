#include <iostream>
using namespace std;
class punkt;

class kolo
{
private:
	double x, y, z;
public:
	kolo(double x = 0, double y = 0, double z = 0) {
		this->x = x;
		this->y = y;
		this->z = z;

	};
	~kolo();
	friend void sedzia(const kolo*, const punkt*);


};

class punkt
{
private:
	double p1, p2;
public:
	punkt(double p1 = 0, double p2 = 0) {
		this->p1 = p1;
		this->p2 = p2;
	};
	virtual~punkt();
	friend void sedzia(const kolo*, const punkt*);
};
