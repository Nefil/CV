﻿#include "kolo.h"
using namespace std;


kolo::~kolo()
{
	cout << "Destruktor kola wywolany." << endl;
}



punkt::~punkt()
{
	cout << "Destruktor punktu wywolany." << endl;
}

void sedzia(const kolo* Kolo, const punkt* Punkt)
{
	if (pow(((Punkt->p1) - (Kolo->x)), 2) + pow(((Punkt->p2) - (Kolo->y)), 2) <= pow((Kolo->z), 2)) {
		cout << "Punkt lezy na kole." << endl;
	}
	else
	{
		cout << "Punkt nie lezy na kole." << endl;
	}

}