
#include "kolo.h"



int main()
{
	double x, y, z;
	cout << "podaj x z kola" << endl;
	cin >> x;
	cout << "podaj y z kola" << endl;
	cin >> y;
	cout << "podaj z z kola" << endl;

	do
	{
		cout << "z musi by� wi�ksze od 0 \n podaj d�ugo�� z" << endl;
		cin >> z;
	} while (z <= 0);

	kolo kolo1(x, y, z);

	double p1, p2;
	cout << "podaj p1" << endl;
	cin >> p1;
	cout << "podaj p2" << endl;
	cin >> p2;

	punkt punkt1(p1, p2);
	sedzia(&kolo1, &punkt1);
	return 0;

}

